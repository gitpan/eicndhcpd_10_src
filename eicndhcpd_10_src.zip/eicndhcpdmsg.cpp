#include <windows.h>
#include "eicndhcpdmsg.h"

BOOL WINAPI DllEntryPoint(HINSTANCE hInstance,
									DWORD reason,
                           LPVOID reserved)
{
	return TRUE;
}